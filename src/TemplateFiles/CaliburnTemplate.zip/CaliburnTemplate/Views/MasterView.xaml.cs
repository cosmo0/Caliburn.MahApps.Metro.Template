﻿namespace $safeprojectname$.Views
{
    using System.Windows.Controls;

    /// <summary>
    /// Interaction logic for MasterView.xaml
    /// </summary>
    public partial class MasterView : UserControl
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MasterView"/> class
        /// </summary>
        public MasterView()
        {
            this.InitializeComponent();
        }
    }
}