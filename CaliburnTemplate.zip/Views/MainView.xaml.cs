﻿namespace $safeprojectname$.Views
{
    using System.Windows.Controls;

    /// <summary>
    /// Interaction logic for MainView.xaml
    /// </summary>
    public partial class MainView : UserControl
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MainView"/> class
        /// </summary>
        public MainView()
        {
            this.InitializeComponent();
        }
    }
}