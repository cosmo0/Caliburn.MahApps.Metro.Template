﻿namespace $safeprojectname$.Windows
{
    /// <summary>
    /// Interaction logic for BaseDialogWindow.xaml
    /// </summary>
    public partial class BaseDialogWindow
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BaseDialogWindow"/> class
        /// </summary>
        public BaseDialogWindow()
        {
            this.InitializeComponent();
        }
    }
}