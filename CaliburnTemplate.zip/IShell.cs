﻿namespace $safeprojectname$
{
    /// <summary>
    /// Provides an interface for the main view model
    /// </summary>
    internal interface IShell
    {
    }
}